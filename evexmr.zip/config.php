<?

$UserAgent = "xxxxxxx";
$Email = "xxxxxxxx";
$Password = "xxxxxxx";

//Masukkan Cookie -> cf_clearance atau PHPSESSID
$Cookie = "xxxxxxxxx";